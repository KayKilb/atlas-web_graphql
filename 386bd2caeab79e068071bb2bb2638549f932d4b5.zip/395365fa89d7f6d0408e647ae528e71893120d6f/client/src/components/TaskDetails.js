function TaskDetails(props) {
  console.log(props);


  return ( <
    div id = "task-details" >
    <
    /
    div >
  );
}

export default TaskDetails;
